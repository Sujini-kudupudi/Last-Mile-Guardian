"use client"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { FileText, Loader2, ArrowRight, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { UploadCard } from "@/components/upload-card"
import { StepFlow } from "@/components/step-flow"

async function extractText(): Promise<string> {
  // Simulate OCR processing delay
  await new Promise((resolve) => setTimeout(resolve, 1500))
  return "Paracetamol 500mg, Metformin 850mg"
}

export default function UploadPage() {
  const router = useRouter()
  const [selectedFile, setSelectedFile] = useState<File | null>(null)
  const [extractedText, setExtractedText] = useState<string | null>(null)
  const [isExtracting, setIsExtracting] = useState(false)
  const [isAnalyzing, setIsAnalyzing] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const currentStep = extractedText ? 2 : 1

  const handleExtract = async () => {
    if (!selectedFile) return

    setIsExtracting(true)
    setError(null)
    setExtractedText(null)

    try {
      const text = await extractText()
      setExtractedText(text)
    } catch {
      setError("Failed to extract text from image")
    } finally {
      setIsExtracting(false)
    }
  }

  const handleAnalyze = async () => {
    if (!extractedText) return

    setIsAnalyzing(true)
    setError(null)

    try {
      const response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ text: extractedText }),
      })

      if (!response.ok) {
        throw new Error("Analysis failed")
      }

      const data = await response.json()
      // Store in sessionStorage for dashboard
      sessionStorage.setItem("medicines", JSON.stringify(data.medicines))
      sessionStorage.setItem("confidence", JSON.stringify(data.confidence))
      router.push("/dashboard")
    } catch {
      setError("Failed to analyze prescription")
    } finally {
      setIsAnalyzing(false)
    }
  }

  return (
    <main className="min-h-screen p-4 md:p-8 bg-gradient-subtle">
      <div className="max-w-xl mx-auto">
        {/* Hero Section */}
        <header className="text-center mb-6">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-primary/10 rounded-full mb-4">
            <Shield className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground text-balance">
            Your Medicine Safety Assistant
          </h1>
          <p className="mt-2 text-lg text-muted-foreground">
            Never miss or mix the wrong medicine again
          </p>
        </header>

        {/* Step Flow */}
        <StepFlow currentStep={currentStep} />

        <div className="space-y-6">
          <UploadCard
            selectedFile={selectedFile}
            onFileSelect={setSelectedFile}
          />

          {selectedFile && !extractedText && (
            <Button
              onClick={handleExtract}
              disabled={isExtracting}
              size="lg"
              className="w-full h-14 text-lg"
            >
              {isExtracting ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Extracting Text...
                </>
              ) : (
                <>
                  <FileText className="h-5 w-5" />
                  Extract Text
                </>
              )}
            </Button>
          )}

          {extractedText && (
            <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
              <h3 className="text-sm font-medium text-muted-foreground mb-2">
                Extracted Text
              </h3>
              <p className="text-lg text-foreground">{extractedText}</p>
            </div>
          )}

          {extractedText && (
            <Button
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              size="lg"
              className="w-full h-14 text-lg"
            >
              {isAnalyzing ? (
                <>
                  <Loader2 className="h-5 w-5 animate-spin" />
                  Analyzing prescription using AI...
                </>
              ) : (
                <>
                  Analyze Prescription
                  <ArrowRight className="h-5 w-5" />
                </>
              )}
            </Button>
          )}

          {error && (
            <div className="bg-destructive/10 border border-destructive rounded-lg p-4 text-center">
              <p className="text-destructive font-medium">{error}</p>
            </div>
          )}
        </div>

        {/* Features Preview */}
        <div className="mt-12 grid grid-cols-3 gap-4 text-center">
          <div className="p-4">
            <div className="w-10 h-10 mx-auto bg-safe/10 rounded-full flex items-center justify-center mb-2">
              <span className="text-safe text-lg">✓</span>
            </div>
            <p className="text-sm text-muted-foreground">Drug Interaction Checks</p>
          </div>
          <div className="p-4">
            <div className="w-10 h-10 mx-auto bg-primary/10 rounded-full flex items-center justify-center mb-2">
              <span className="text-primary text-lg">🔔</span>
            </div>
            <p className="text-sm text-muted-foreground">Dose Reminders</p>
          </div>
          <div className="p-4">
            <div className="w-10 h-10 mx-auto bg-amber-100 rounded-full flex items-center justify-center mb-2">
              <span className="text-amber-600 text-lg">👥</span>
            </div>
            <p className="text-sm text-muted-foreground">Caregiver Alerts</p>
          </div>
        </div>
      </div>
    </main>
  )
}
