export async function checkDrugMCP(medicines: string[]) {
  if (
    medicines.includes("ibuprofen") &&
    medicines.includes("aspirin")
  ) {
    return {
      conflict: true,
      message: "⚠️ Ibuprofen + Aspirin may cause bleeding risk",
    };
  }

  return {
    conflict: false,
    message: null,
  };
}