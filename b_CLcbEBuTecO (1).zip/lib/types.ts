export interface Medicine {
  name: string
  timing: "morning" | "afternoon" | "night"
  food: "before" | "after"
  instructions: string
  risk: string
  tips?: string[]
}

export interface AnalyzeResponse {
  medicines: Medicine[]
  confidence: number
}

export interface AdherenceDay {
  date: string
  completed: number
  total: number
}

export interface DrugIssue {
  level: "danger" | "warning"
  message: string
  explanation?: string
}
