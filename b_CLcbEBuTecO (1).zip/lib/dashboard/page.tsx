"use client"

import { useEffect, useState } from "react"
import Link from "next/link"
import { ArrowLeft, AlertTriangle, ToggleLeft, ToggleRight, Bell, Loader2, Shield } from "lucide-react"
import { Button } from "@/components/ui/button"
import { MedicineCard } from "@/components/medicine-card"
import { AlertBox } from "@/components/alert-box"
import { VoiceButton } from "@/components/voice-button"
import { HealthScore } from "@/components/health-score"
import { AdherenceTracker } from "@/components/adherence-tracker"
import { ConfidenceIndicator } from "@/components/confidence-indicator"
import { RiskExplanation } from "@/components/risk-explanation"
import type { Medicine, DrugIssue, AdherenceDay } from "@/lib/types"

// Safety engine with explanations
function checkDrugInteractions(medicines: Medicine[]): DrugIssue[] | null {
  const names = medicines.map((m) => m.name.toLowerCase())
  const issues: DrugIssue[] = []

  if (names.includes("paracetamol") && names.includes("alcohol")) {
    issues.push({
      level: "danger",
      message: "Paracetamol combined with alcohol can cause serious liver damage.",
      explanation: "Both paracetamol and alcohol are processed by your liver. When taken together, they can overwhelm the liver and cause toxic buildup, leading to liver failure in severe cases.",
    })
  }

  if (names.includes("ibuprofen") && names.includes("aspirin")) {
    issues.push({
      level: "warning",
      message: "Ibuprofen and Aspirin together may increase risk of bleeding.",
      explanation: "Both medications are NSAIDs that thin the blood. Combining them increases the risk of stomach bleeding and ulcers, especially in elderly patients.",
    })
  }

  if (names.includes("metformin") && names.includes("alcohol")) {
    issues.push({
      level: "danger",
      message: "Metformin with alcohol increases risk of lactic acidosis.",
      explanation: "Alcohol interferes with how your body processes Metformin, which can lead to a dangerous buildup of lactic acid in your blood, causing muscle pain, weakness, and breathing difficulties.",
    })
  }

  return issues.length ? issues : null
}

// Generate mock adherence data for the past 7 days
function generateAdherenceData(): AdherenceDay[] {
  const days: AdherenceDay[] = []
  const today = new Date()
  
  for (let i = 6; i >= 0; i--) {
    const date = new Date(today)
    date.setDate(date.getDate() - i)
    const total = 2
    const completed = i === 0 ? 1 : i === 1 ? 2 : Math.floor(Math.random() * 3)
    days.push({
      date: date.toISOString().split("T")[0],
      completed: Math.min(completed, total),
      total,
    })
  }
  
  return days
}

export default function DashboardPage() {
  const [medicines, setMedicines] = useState<Medicine[]>([])
  const [confidence, setConfidence] = useState(85)
  const [interactionIssues, setInteractionIssues] = useState<DrugIssue[] | null>(null)
  const [showExplanation, setShowExplanation] = useState(false)
  const [caregiverMode, setCaregiverMode] = useState(false)
  const [missedDoseAlert, setMissedDoseAlert] = useState(false)
  const [language, setLanguage] = useState<"en-US" | "te-IN">("en-US")
  const [completedDoses, setCompletedDoses] = useState(1)
  const [adherenceData] = useState<AdherenceDay[]>(generateAdherenceData)
  const [mcpLoading, setMcpLoading] = useState(false)
  const [mcpConfidence, setMcpConfidence] = useState(94)

  useEffect(() => {
    const storedMedicines = sessionStorage.getItem("medicines")
    const storedConfidence = sessionStorage.getItem("confidence")
    
    if (storedMedicines) {
      setMedicines(JSON.parse(storedMedicines))
    }
    if (storedConfidence) {
      setConfidence(JSON.parse(storedConfidence))
    }
  }, [])

  const handleSimulateConflict = async () => {
    setMcpLoading(true)
    setInteractionIssues(null)
    setShowExplanation(false)
    
    // Simulate MCP analysis delay
    await new Promise((resolve) => setTimeout(resolve, 1500))
    
    const medicinesWithAlcohol: Medicine[] = [
      ...medicines,
      {
        name: "Alcohol",
        timing: "night",
        food: "after",
        instructions: "Consumed with dinner",
        risk: "Dangerous",
      },
    ]
    const issues = checkDrugInteractions(medicinesWithAlcohol)
    setMcpConfidence(Math.floor(Math.random() * 10) + 90) // 90-99%
    setInteractionIssues(issues)
    setMcpLoading(false)
  }
  const handleSimulateConflict = async () => {
  setMcpLoading(true)
  setInteractionIssues(null)
  setShowExplanation(false)

  const names = medicines.map((m) => m.name.toLowerCase())

  try {
    const res = await fetch("/mcp", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ medicines: names }),
    })

    const data = await res.json()

    if (data.conflict) {
      setInteractionIssues([
        {
          level: "danger",
          message: data.message,
          explanation: "This alert is generated using MCP safety tool.",
        },
      ])
    }
  } catch (err) {
    console.error("MCP error:", err)
  }

  setMcpLoading(false)
}

  const handleMarkComplete = () => {
    setCompletedDoses((prev) => Math.min(prev + 1, medicines.length))
  }

  // Calculate adherence rate
  const adherenceRate = adherenceData.length > 0
    ? Math.round(
        (adherenceData.reduce((sum, d) => sum + d.completed, 0) /
          adherenceData.reduce((sum, d) => sum + d.total, 0)) *
          100
      )
    : 100

  const riskCount = medicines.filter((m) => m.risk !== "Safe").length

  if (medicines.length === 0) {
    return (
      <main className="min-h-screen p-4 md:p-8 bg-gradient-subtle">
        <div className="max-w-2xl mx-auto text-center py-12">
          <h1 className="text-2xl font-bold text-foreground mb-4">
            No Medicines Found
          </h1>
          <p className="text-muted-foreground mb-6">
            Please upload and analyze a prescription first.
          </p>
          <Link href="/">
            <Button size="lg" className="h-14 text-lg">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Go to Upload
            </Button>
          </Link>
        </div>
      </main>
    )
  }

  // Group medicines by timing
  const morningMeds = medicines.filter((m) => m.timing === "morning")
  const afternoonMeds = medicines.filter((m) => m.timing === "afternoon")
  const nightMeds = medicines.filter((m) => m.timing === "night")

  return (
    <main className="min-h-screen p-4 md:p-8 pb-24 bg-gradient-subtle">
      <div className="max-w-2xl mx-auto">
        <header className="mb-6">
          <Link
            href="/"
            className="inline-flex items-center text-muted-foreground hover:text-foreground transition-colors mb-4"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Upload
          </Link>
          <div className="flex items-start justify-between gap-4">
            <div>
              <h1 className="text-3xl md:text-4xl font-bold text-foreground">
                {"Today's Medicine Plan"}
              </h1>
              <p className="mt-2 text-lg text-muted-foreground">
                Follow this schedule to stay safe
              </p>
            </div>
            <ConfidenceIndicator confidence={confidence} />
          </div>
        </header>

        {/* Health Score & Progress */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
          <HealthScore adherenceRate={adherenceRate} riskCount={riskCount} />
          
          {/* Progress Tracker */}
          <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
            <div className="flex items-center justify-between mb-3">
              <span className="font-medium text-foreground">Today&apos;s Progress</span>
              <span className="text-lg font-semibold text-primary">
                {completedDoses} of {medicines.length}
              </span>
            </div>
            <div className="h-3 bg-muted rounded-full overflow-hidden">
              <div
                className="h-full bg-safe transition-all duration-300"
                style={{ width: `${(completedDoses / medicines.length) * 100}%` }}
              />
            </div>
            <p className="mt-2 text-sm text-muted-foreground">
              {completedDoses === medicines.length
                ? "All doses completed!"
                : `${medicines.length - completedDoses} doses remaining`}
            </p>
          </div>
        </div>

        {/* Adherence Tracker */}
        <div className="mb-6">
          <AdherenceTracker days={adherenceData} />
        </div>

        {/* MCP Loading State */}
        {mcpLoading && (
          <div className="mb-6 bg-primary/5 border-2 border-primary/20 rounded-xl p-6">
            <div className="flex items-center gap-4">
              <div className="p-3 bg-primary/10 rounded-full">
                <Shield className="h-6 w-6 text-primary animate-pulse" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <span className="font-semibold text-foreground">
                    Checking interactions via MCP...
                  </span>
                </div>
                <p className="text-sm text-muted-foreground mt-1">
                  Analyzing drug combinations for safety
                </p>
              </div>
            </div>
          </div>
        )}

        {/* Alerts Section */}
        {interactionIssues && !showExplanation && !mcpLoading && (
          <div className="mb-6">
            <AlertBox
              issues={interactionIssues}
              confidence={mcpConfidence}
              onClose={() => setInteractionIssues(null)}
              onShowExplanation={() => setShowExplanation(true)}
            />
          </div>
        )}

        {/* Risk Explanation Panel */}
        {showExplanation && interactionIssues && (
          <div className="mb-6">
            <RiskExplanation
              issues={interactionIssues}
              onClose={() => setShowExplanation(false)}
            />
          </div>
        )}

        {/* Missed Dose Alert */}
        {missedDoseAlert && (
          <div className="mb-6 bg-amber-50 border-2 border-amber-400 rounded-xl p-5 animate-shake">
            <div className="flex items-start gap-4">
              <div className="p-3 bg-amber-100 rounded-full">
                <Bell className="h-6 w-6 text-amber-600" />
              </div>
              <div className="flex-1">
                <h4 className="text-lg font-semibold text-amber-900">
                  Missed dose detected
                </h4>
                <p className="mt-1 text-amber-800">
                  Caregiver has been notified
                </p>
              </div>
              <button
                onClick={() => setMissedDoseAlert(false)}
                className="text-amber-600 hover:text-amber-800 font-medium"
              >
                Dismiss
              </button>
            </div>
          </div>
        )}

        {/* Medicine Cards grouped by timing */}
        <div className="space-y-6 mb-6">
          {morningMeds.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-amber-500">☀️</span>
                <span>Morning</span>
              </h2>
              <div className="space-y-4">
                {morningMeds.map((medicine, index) => (
                  <MedicineCard
                    key={`morning-${index}`}
                    medicine={medicine}
                    onMarkComplete={handleMarkComplete}
                  />
                ))}
              </div>
            </div>
          )}

          {afternoonMeds.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-sky-500">🌤️</span>
                <span>Afternoon</span>
              </h2>
              <div className="space-y-4">
                {afternoonMeds.map((medicine, index) => (
                  <MedicineCard
                    key={`afternoon-${index}`}
                    medicine={medicine}
                    onMarkComplete={handleMarkComplete}
                  />
                ))}
              </div>
            </div>
          )}

          {nightMeds.length > 0 && (
            <div>
              <h2 className="text-lg font-semibold text-foreground mb-3 flex items-center gap-2">
                <span className="text-indigo-500">🌙</span>
                <span>Night</span>
              </h2>
              <div className="space-y-4">
                {nightMeds.map((medicine, index) => (
                  <MedicineCard
                    key={`night-${index}`}
                    medicine={medicine}
                    onMarkComplete={handleMarkComplete}
                  />
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Caregiver Mode Toggle */}
        <div className="bg-card border border-border rounded-xl p-4 mb-6 shadow-sm">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="font-semibold text-foreground">Enable Caregiver Mode</h3>
              {caregiverMode && (
                <p className="text-sm text-safe font-medium mt-1">
                  Caregiver monitoring active
                </p>
              )}
            </div>
            <button
              onClick={() => setCaregiverMode(!caregiverMode)}
              className="text-primary hover:text-primary/80 transition-colors"
              aria-label={caregiverMode ? "Disable caregiver mode" : "Enable caregiver mode"}
            >
              {caregiverMode ? (
                <ToggleRight className="h-10 w-10" />
              ) : (
                <ToggleLeft className="h-10 w-10 text-muted-foreground" />
              )}
            </button>
          </div>
          {caregiverMode && (
            <div className="mt-4">
              <Button
                onClick={handleSimulateMissedDose}
                variant="outline"
                size="lg"
                className="w-full h-12 text-base"
              >
                Simulate Missed Dose
              </Button>
            </div>
          )}
        </div>

        {/* Language Toggle */}
        <div className="bg-card border border-border rounded-xl p-4 mb-6 shadow-sm">
          <div className="flex items-center justify-between">
            <span className="font-medium text-foreground">Voice Language</span>
            <div className="flex gap-2">
              <Button
                variant={language === "en-US" ? "default" : "outline"}
                size="sm"
                onClick={() => setLanguage("en-US")}
              >
                English
              </Button>
              <Button
                variant={language === "te-IN" ? "default" : "outline"}
                size="sm"
                onClick={() => setLanguage("te-IN")}
              >
                Telugu
              </Button>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex flex-col sm:flex-row gap-4">
          <VoiceButton medicines={medicines} language={language} />
          <Button
            onClick={handleSimulateConflict}
            size="lg"
            variant="destructive"
            className="h-14 px-6 text-lg gap-3"
          >
            <AlertTriangle className="h-6 w-6" />
            Simulate Wrong Combination
          </Button>
        </div>
      </div>
    </main>
  )
}
