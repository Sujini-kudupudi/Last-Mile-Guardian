"use client"

import { AlertTriangle, X, Info, Shield } from "lucide-react"
import type { DrugIssue } from "@/lib/types"

interface AlertBoxProps {
  issues: DrugIssue[]
  confidence?: number
  onClose?: () => void
  onShowExplanation?: () => void
}

export function AlertBox({ issues, confidence = 94, onClose, onShowExplanation }: AlertBoxProps) {
  return (
    <div className="bg-gradient-to-r from-red-600 to-red-700 rounded-xl p-6 shadow-xl animate-shake">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 mb-5">
        <div className="flex items-center gap-3">
          <div className="p-2 bg-white/20 rounded-full">
            <AlertTriangle className="h-8 w-8 text-white" />
          </div>
          <h3 className="text-2xl md:text-3xl font-bold text-white">
            DANGEROUS COMBINATION DETECTED
          </h3>
        </div>
        {onClose && (
          <button
            onClick={onClose}
            className="text-white/80 hover:text-white transition-colors p-1"
            aria-label="Dismiss alert"
          >
            <X className="h-7 w-7" />
          </button>
        )}
      </div>

      {/* Issues List */}
      <div className="space-y-3 mb-5">
        {issues.map((issue, index) => (
          <div
            key={index}
            className={`flex items-start gap-3 p-4 rounded-lg ${
              issue.level === "danger"
                ? "bg-white/95 text-red-900"
                : "bg-orange-50 text-orange-900"
            }`}
          >
            <span className="text-xl flex-shrink-0 mt-0.5">
              {issue.level === "danger" ? "🔴" : "🟠"}
            </span>
            <div className="flex-1">
              <span className="inline-block px-2 py-0.5 text-xs font-bold uppercase rounded mb-1 bg-red-100 text-red-700">
                {issue.level}
              </span>
              <p className="font-semibold text-lg">{issue.message}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Footer with MCP Source and Confidence */}
      <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-white/20">
        <div className="flex items-center gap-3 text-white/90">
          <Shield className="h-5 w-5" />
          <span className="text-sm font-medium">Source: MCP Safety Engine</span>
          <span className="px-2 py-1 bg-white/20 rounded text-sm font-bold">
            Confidence: {confidence}%
          </span>
        </div>
        {onShowExplanation && (
          <button
            onClick={onShowExplanation}
            className="flex items-center gap-2 text-sm font-medium text-white hover:text-white/80 transition-colors"
          >
            <Info className="h-4 w-4" />
            Why is this risky?
          </button>
        )}
      </div>
    </div>
  )
}
