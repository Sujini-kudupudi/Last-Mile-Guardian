"use client"

import { Sun, Cloud, Moon, Utensils, Lightbulb } from "lucide-react"
import type { Medicine } from "@/lib/types"

interface MedicineCardProps {
  medicine: Medicine
  onMarkComplete?: () => void
}

function getTimingIcon(timing: Medicine["timing"]) {
  switch (timing) {
    case "morning":
      return <Sun className="h-6 w-6 text-amber-500" />
    case "afternoon":
      return <Cloud className="h-6 w-6 text-sky-500" />
    case "night":
      return <Moon className="h-6 w-6 text-indigo-500" />
  }
}

function getTimingLabel(timing: Medicine["timing"]) {
  switch (timing) {
    case "morning":
      return "Morning"
    case "afternoon":
      return "Afternoon"
    case "night":
      return "Night"
  }
}

export function MedicineCard({ medicine, onMarkComplete }: MedicineCardProps) {
  const isSafe = medicine.risk === "Safe"
  const borderClass = isSafe ? "border-safe" : "border-risk"

  return (
    <div className={`bg-card rounded-xl border-2 ${borderClass} p-5 shadow-sm transition-shadow hover:shadow-md`}>
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <h3 className="text-xl font-semibold text-card-foreground">
            {medicine.name}
          </h3>
          <div className="mt-3 flex items-center gap-2 text-muted-foreground">
            {getTimingIcon(medicine.timing)}
            <span className="text-base">{getTimingLabel(medicine.timing)}</span>
          </div>
          <div className="mt-2 flex items-center gap-2 text-muted-foreground">
            <Utensils className="h-5 w-5" />
            <span className="text-base capitalize">{medicine.food} food</span>
          </div>
          <p className="mt-3 text-base text-foreground">
            {medicine.instructions}
          </p>
          {!isSafe && (
            <p className="mt-2 text-sm font-medium text-risk">
              {medicine.risk}
            </p>
          )}
        </div>
        <div className="flex flex-col items-end gap-2">
          <div
            className={`px-3 py-1.5 rounded-full text-sm font-medium ${
              isSafe
                ? "bg-safe/10 text-safe"
                : "bg-risk/10 text-risk"
            }`}
          >
            {isSafe ? "Safe" : "Risk"}
          </div>
          {onMarkComplete && (
            <button
              onClick={onMarkComplete}
              className="text-sm text-primary hover:text-primary/80 font-medium"
            >
              Mark Done
            </button>
          )}
        </div>
      </div>

      {/* Quick Tip - Always Visible */}
      {medicine.tips && medicine.tips.length > 0 && (
        <div className="mt-4 pt-4 border-t border-border">
          <div className="flex items-start gap-2 p-3 bg-amber-50 rounded-lg">
            <Lightbulb className="h-5 w-5 text-amber-600 flex-shrink-0 mt-0.5" />
            <div>
              <span className="text-sm font-semibold text-amber-900">Tip: </span>
              <span className="text-sm text-amber-800">{medicine.tips[0]}</span>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
