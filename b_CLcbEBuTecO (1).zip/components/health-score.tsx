"use client"

import { Heart } from "lucide-react"

interface HealthScoreProps {
  adherenceRate: number
  riskCount: number
}

export function HealthScore({ adherenceRate, riskCount }: HealthScoreProps) {
  // Calculate health score: base 100, minus penalties for risks and low adherence
  const riskPenalty = riskCount * 15
  const adherencePenalty = Math.max(0, (100 - adherenceRate) * 0.5)
  const score = Math.max(0, Math.min(100, 100 - riskPenalty - adherencePenalty))
  
  const getScoreColor = () => {
    if (score >= 80) return "text-safe"
    if (score >= 60) return "text-amber-500"
    return "text-risk"
  }

  const getScoreLabel = () => {
    if (score >= 80) return "Excellent"
    if (score >= 60) return "Good"
    if (score >= 40) return "Fair"
    return "Needs Attention"
  }

  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <div className="flex items-center gap-4">
        <div className="relative">
          <svg className="w-20 h-20 transform -rotate-90">
            <circle
              cx="40"
              cy="40"
              r="36"
              fill="none"
              stroke="currentColor"
              strokeWidth="6"
              className="text-muted"
            />
            <circle
              cx="40"
              cy="40"
              r="36"
              fill="none"
              stroke="currentColor"
              strokeWidth="6"
              strokeLinecap="round"
              strokeDasharray={`${(score / 100) * 226} 226`}
              className={getScoreColor()}
            />
          </svg>
          <div className="absolute inset-0 flex items-center justify-center">
            <Heart className={`h-6 w-6 ${getScoreColor()}`} />
          </div>
        </div>
        <div>
          <h3 className="text-sm font-medium text-muted-foreground">Health Score</h3>
          <p className={`text-3xl font-bold ${getScoreColor()}`}>{Math.round(score)}</p>
          <p className="text-sm text-muted-foreground">{getScoreLabel()}</p>
        </div>
      </div>
    </div>
  )
}
