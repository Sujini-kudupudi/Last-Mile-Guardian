"use client"

import { Upload, Search, Shield, Check } from "lucide-react"

interface StepFlowProps {
  currentStep: 1 | 2 | 3
}

const steps = [
  { id: 1, label: "Upload", icon: Upload },
  { id: 2, label: "Analyze", icon: Search },
  { id: 3, label: "Stay Safe", icon: Shield },
]

export function StepFlow({ currentStep }: StepFlowProps) {
  return (
    <div className="flex items-center justify-center gap-2 mb-8">
      {steps.map((step, index) => {
        const isCompleted = step.id < currentStep
        const isCurrent = step.id === currentStep
        const Icon = step.icon

        return (
          <div key={step.id} className="flex items-center">
            <div className="flex flex-col items-center">
              <div
                className={`w-12 h-12 rounded-full flex items-center justify-center transition-colors ${
                  isCompleted
                    ? "bg-safe text-safe-foreground"
                    : isCurrent
                    ? "bg-primary text-primary-foreground"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {isCompleted ? (
                  <Check className="h-6 w-6" />
                ) : (
                  <Icon className="h-5 w-5" />
                )}
              </div>
              <span
                className={`mt-2 text-sm font-medium ${
                  isCurrent ? "text-foreground" : "text-muted-foreground"
                }`}
              >
                {step.label}
              </span>
            </div>
            {index < steps.length - 1 && (
              <div
                className={`w-12 h-0.5 mx-2 ${
                  isCompleted ? "bg-safe" : "bg-muted"
                }`}
              />
            )}
          </div>
        )
      })}
    </div>
  )
}
