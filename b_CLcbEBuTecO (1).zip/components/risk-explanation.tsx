"use client"

import { Info, X } from "lucide-react"
import type { DrugIssue } from "@/lib/types"

interface RiskExplanationProps {
  issues: DrugIssue[]
  onClose: () => void
}

export function RiskExplanation({ issues, onClose }: RiskExplanationProps) {
  return (
    <div className="bg-card border border-border rounded-xl shadow-lg overflow-hidden">
      <div className="bg-risk/10 px-5 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Info className="h-5 w-5 text-risk" />
          <h3 className="font-semibold text-risk">Why is this risky?</h3>
        </div>
        <button
          onClick={onClose}
          className="text-muted-foreground hover:text-foreground transition-colors"
          aria-label="Close explanation"
        >
          <X className="h-5 w-5" />
        </button>
      </div>
      <div className="p-5 space-y-4">
        {issues.map((issue, index) => (
          <div key={index} className="space-y-2">
            <div className="flex items-start gap-3">
              <span className="text-lg flex-shrink-0">
                {issue.level === "danger" ? "🔴" : "🟠"}
              </span>
              <div>
                <p className="font-medium text-foreground">{issue.message}</p>
                {issue.explanation && (
                  <p className="mt-1 text-sm text-muted-foreground">
                    {issue.explanation}
                  </p>
                )}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
