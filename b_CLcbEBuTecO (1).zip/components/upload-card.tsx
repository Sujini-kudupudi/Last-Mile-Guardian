"use client"

import { Upload, FileImage, X } from "lucide-react"
import { useCallback, useState } from "react"
import { Button } from "@/components/ui/button"

interface UploadCardProps {
  onFileSelect: (file: File | null) => void
  selectedFile: File | null
}

export function UploadCard({ onFileSelect, selectedFile }: UploadCardProps) {
  const [isDragging, setIsDragging] = useState(false)

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(true)
  }, [])

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault()
    setIsDragging(false)
  }, [])

  const handleDrop = useCallback(
    (e: React.DragEvent) => {
      e.preventDefault()
      setIsDragging(false)
      const file = e.dataTransfer.files[0]
      if (file && file.type.startsWith("image/")) {
        onFileSelect(file)
      }
    },
    [onFileSelect]
  )

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0]
      if (file) {
        onFileSelect(file)
      }
    },
    [onFileSelect]
  )

  const handleRemove = useCallback(() => {
    onFileSelect(null)
  }, [onFileSelect])

  return (
    <div
      className={`relative border-2 border-dashed rounded-xl p-8 transition-colors ${
        isDragging
          ? "border-primary bg-primary/5"
          : selectedFile
            ? "border-safe bg-safe/5"
            : "border-border bg-card"
      }`}
      onDragOver={handleDragOver}
      onDragLeave={handleDragLeave}
      onDrop={handleDrop}
    >
      {selectedFile ? (
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-3 bg-safe/10 rounded-lg">
              <FileImage className="h-8 w-8 text-safe" />
            </div>
            <div>
              <p className="font-medium text-foreground">{selectedFile.name}</p>
              <p className="text-sm text-muted-foreground">
                {(selectedFile.size / 1024).toFixed(1)} KB
              </p>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon"
            onClick={handleRemove}
            className="text-muted-foreground hover:text-destructive"
          >
            <X className="h-5 w-5" />
          </Button>
        </div>
      ) : (
        <label className="flex flex-col items-center gap-4 cursor-pointer">
          <div className="p-4 bg-secondary rounded-full">
            <Upload className="h-10 w-10 text-muted-foreground" />
          </div>
          <div className="text-center">
            <p className="text-lg font-medium text-foreground">
              Upload Prescription
            </p>
            <p className="text-muted-foreground mt-1">
              Drag and drop or click to browse
            </p>
          </div>
          <input
            type="file"
            accept="image/*"
            onChange={handleFileChange}
            className="sr-only"
          />
        </label>
      )}
    </div>
  )
}
