"use client"

import { Volume2, VolumeX } from "lucide-react"
import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import type { Medicine } from "@/lib/types"

interface VoiceButtonProps {
  medicines: Medicine[]
  language?: "en-US" | "te-IN"
}

export function VoiceButton({ medicines, language = "en-US" }: VoiceButtonProps) {
  const [isSpeaking, setIsSpeaking] = useState(false)
  const [voiceWarning, setVoiceWarning] = useState<string | null>(null)
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([])

  useEffect(() => {
    if (typeof window === "undefined" || !window.speechSynthesis) return

    const loadVoices = () => {
      setVoices(window.speechSynthesis.getVoices())
    }

    loadVoices()
    window.speechSynthesis.onvoiceschanged = loadVoices

    return () => {
      window.speechSynthesis.onvoiceschanged = null
    }
  }, [])

  const readInstructions = () => {
    if (typeof window === "undefined" || !window.speechSynthesis) {
      return
    }

    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
      return
    }

    setVoiceWarning(null)

    const text = medicines
      .map(
        (m) =>
          `${m.name}. ${m.instructions}. ${m.risk !== "Safe" ? `Warning: ${m.risk}` : ""}`
      )
      .join(". ")

    const utterance = new SpeechSynthesisUtterance(text)
    
    // Try to find the requested language voice
    let selectedVoice = voices.find((v) => v.lang.startsWith(language.split("-")[0]))
    
    if (language === "te-IN") {
      const teluguVoice = voices.find((v) => v.lang.includes("te"))
      if (teluguVoice) {
        selectedVoice = teluguVoice
      } else {
        setVoiceWarning("Telugu voice not supported on this device. Playing in English.")
        // Fallback to English
        selectedVoice = voices.find((v) => v.lang.startsWith("en"))
      }
    }

    if (selectedVoice) {
      utterance.voice = selectedVoice
    }
    
    utterance.lang = selectedVoice?.lang || "en-US"
    utterance.rate = 0.9

    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)

    setIsSpeaking(true)
    window.speechSynthesis.speak(utterance)
  }

  return (
    <div className="flex flex-col gap-2">
      <Button
        onClick={readInstructions}
        size="lg"
        variant={isSpeaking ? "destructive" : "secondary"}
        className="h-14 px-6 text-lg gap-3"
      >
        {isSpeaking ? (
          <>
            <VolumeX className="h-6 w-6" />
            Stop Reading
          </>
        ) : (
          <>
            <Volume2 className="h-6 w-6" />
            Read Instructions
          </>
        )}
      </Button>
      {voiceWarning && (
        <p className="text-sm text-amber-600 font-medium flex items-center gap-2">
          <span>⚠</span>
          {voiceWarning}
        </p>
      )}
    </div>
  )
}
