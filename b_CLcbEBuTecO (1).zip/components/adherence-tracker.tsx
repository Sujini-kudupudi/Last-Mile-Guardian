"use client"

import { Check, X } from "lucide-react"
import type { AdherenceDay } from "@/lib/types"

interface AdherenceTrackerProps {
  days: AdherenceDay[]
}

export function AdherenceTracker({ days }: AdherenceTrackerProps) {
  return (
    <div className="bg-card border border-border rounded-xl p-5 shadow-sm">
      <h3 className="text-lg font-semibold text-foreground mb-4">
        Weekly Adherence
      </h3>
      <div className="flex justify-between gap-2">
        {days.map((day, index) => {
          const isComplete = day.completed === day.total
          const percentage = day.total > 0 ? (day.completed / day.total) * 100 : 0
          const dayLabel = new Date(day.date).toLocaleDateString("en-US", { weekday: "short" })
          
          return (
            <div key={index} className="flex flex-col items-center gap-2">
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center ${
                  isComplete
                    ? "bg-safe/20 text-safe"
                    : percentage > 0
                    ? "bg-amber-100 text-amber-600"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {isComplete ? (
                  <Check className="h-5 w-5" />
                ) : percentage > 0 ? (
                  <span className="text-xs font-bold">{Math.round(percentage)}%</span>
                ) : (
                  <X className="h-4 w-4" />
                )}
              </div>
              <span className="text-xs text-muted-foreground">{dayLabel}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
