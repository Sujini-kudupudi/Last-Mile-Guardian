"use client"

import { Brain } from "lucide-react"

interface ConfidenceIndicatorProps {
  confidence: number
}

export function ConfidenceIndicator({ confidence }: ConfidenceIndicatorProps) {
  const getConfidenceColor = () => {
    if (confidence >= 90) return "text-safe bg-safe/10"
    if (confidence >= 70) return "text-amber-600 bg-amber-50"
    return "text-risk bg-risk/10"
  }

  const getConfidenceLabel = () => {
    if (confidence >= 90) return "High Confidence"
    if (confidence >= 70) return "Medium Confidence"
    return "Low Confidence"
  }

  return (
    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium ${getConfidenceColor()}`}>
      <Brain className="h-4 w-4" />
      <span>AI: {getConfidenceLabel()} ({confidence}%)</span>
    </div>
  )
}
